#include <iostream>
#include <thread>
#include <chrono>

enum class TrafficLightColor {
    RED,
    GREEN,
    YELLOW
};

class TrafficLight {
public:
    TrafficLight() : currentColor(TrafficLightColor::RED) {}

    void start() {
        isRunning = true;
        controlThread = std::thread(&TrafficLight::controlLoop, this);
    }

    void stop() {
        isRunning = false;
        if (controlThread.joinable()) {
            controlThread.join();
        }
    }

private:
    void controlLoop() {
        while (isRunning) {
            switch (currentColor) {
                case TrafficLightColor::RED:
                    std::cout << "RED light\n";
                    std::this_thread::sleep_for(std::chrono::seconds(5));
                    currentColor = TrafficLightColor::GREEN;
                    break;
                case TrafficLightColor::GREEN:
                    std::cout << "GREEN light\n";
                    std::this_thread::sleep_for(std::chrono::seconds(10));
                    currentColor = TrafficLightColor::YELLOW;
                    break;
                case TrafficLightColor::YELLOW:
                    std::cout << "YELLOW light\n";
                    std::this_thread::sleep_for(std::chrono::seconds(2));
                    currentColor = TrafficLightColor::RED;
                    break;
            }
        }
    }

    TrafficLightColor currentColor;
    bool isRunning = false;
    std::thread controlThread;
};

int main() {
    TrafficLight trafficLight;
    trafficLight.start();

    // Let the traffic light control for a while
    std::this_thread::sleep_for(std::chrono::seconds(30));

    trafficLight.stop();

    return 0;
}
